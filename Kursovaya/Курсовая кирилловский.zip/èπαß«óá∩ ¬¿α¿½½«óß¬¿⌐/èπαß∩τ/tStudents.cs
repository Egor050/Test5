﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курсяч
{
    class tStudents
    {
        string portrait, name, surname;
        int kurs, otsenka;
        public tStudents(string a1,string a, string b, int c,int d)
        {
            portrait = a1;
            name = a;
            surname = b;
            kurs = c;
            otsenka = d;
        }
        public string Portrait()
        {
            return portrait;
        }
        public string Name()
        {
            return name;
        }
        public string Surname()
        {
            return surname;
        }
        public int Kurs()
        {
            return kurs;
        }
        public int Otsenka()
        {
            return otsenka;
        }       
    }
}

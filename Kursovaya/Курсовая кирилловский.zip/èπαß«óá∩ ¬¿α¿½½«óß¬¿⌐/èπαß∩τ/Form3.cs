﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Курсяч
{
    public partial class Form3 : Form
    {
        private static string pathPic;
        static int q = 0, p = 0;
        static string path;
        public Form3()
        {
            InitializeComponent();          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            q++;
            label5.Text = q.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            q--;
            label5.Text = q.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            p++;
            label6.Text = p.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            p--;
            label6.Text = p.ToString();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pathPic = openFileDialog1.FileName;
            }
            pictureBox1.Image = new Bitmap(pathPic);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 result = new Form1(); //создаем экземпляр класса Form2
            result.Show(); //отображаем форму с результатом
            result.Location = this.Location; //открытая форма сохраняет расположение главной формы
            this.Hide(); //скрываем главную форму
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == ""|textBox2.Text=="")
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                Directory.CreateDirectory(Class1.path + "\\" + textBox1.Text);
                File.Create(Class1.path + "\\" + textBox1.Text + "\\Новый текстовый документ.txt");
                File.Create(Class1.path + "\\" + textBox1.Text + "\\портрет.jpg");
            }       
            MessageBox.Show("Пока-что не работает. Лол. Слава Губке Бобу!");
        }

        //private void Zero_ammount()
        //{
        //    label5.Text = q.ToString();
        //    label6.Text = p.ToString();
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курсяч
{
    class Class1
    {
        static public string path = "E:\\УчЁБА\\програмирование\\ъКУРСЯЧ\\Данные\\Студенты";
        static public string defimage = "E:\\УчЁБА\\програмирование\\ъКУРСЯЧ\\Курсяч\\bin\\Debug\\images\\main";
        static public string Pathh()
        {
            return path;
        }
    }
}
